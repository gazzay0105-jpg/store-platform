# Store Platform 🛍️

Next.js 14 + Supabase ашигласан Монгол дэлгүүрийн платформ.

## Суулгах заавар

### 1. Supabase тохиргоо

1. [Supabase Dashboard](https://supabase.com/dashboard) нэвтэрч `ncqldmamsgwxqnbkgstz` төсөл рүүгээ орно
2. **SQL Editor** цэс дээр дарна
3. `supabase-schema.sql` файлын агуулгыг бүгдийг нь хуулж, SQL editor-т оруулж **Run** дарна
4. **Settings → API** хэсгээс `anon key` болон `service_role key`-г авна

### 2. Environment variables

`.env.local` файлыг үүсгэж доорх мэдээллийг оруулна:

```bash
NEXT_PUBLIC_SUPABASE_URL=https://ncqldmamsgwxqnbkgstz.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key-here
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key-here
```

### 3. Локалд ажиллуулах

```bash
npm install
npm run dev
```

http://localhost:3000 дээр нээгдэнэ.

### 4. Vercel-д deploy хийх

```bash
# Vercel CLI
npm i -g vercel
vercel

# Эсвэл GitHub-т push хийгээд Vercel-д холбоно
git add .
git commit -m "feat: complete store platform"
git push origin main
```

Vercel-д environment variables нэмэхээ мартуузай!

### 5. Adminа тохиргоо

Бүртгүүлсний дараа Supabase SQL Editor-т:

```sql
UPDATE profiles SET role = 'admin' WHERE email = 'your-email@example.com';
```

## Файлын бүтэц

```
src/
├── app/
│   ├── page.tsx                    # Нүүр хуудас
│   ├── layout.tsx                  # Root layout
│   ├── globals.css                 # Global styles
│   ├── auth/
│   │   ├── login/page.tsx          # Нэвтрэх
│   │   └── register/page.tsx       # Бүртгүүлэх
│   ├── products/
│   │   ├── page.tsx                # Бараа жагсаалт
│   │   └── [slug]/page.tsx         # Бараа дэлгэрэнгүй
│   ├── cart/page.tsx               # Сагс
│   ├── checkout/page.tsx           # Захиалга хийх
│   ├── profile/page.tsx            # Профайл & захиалгууд
│   └── admin/
│       ├── dashboard/page.tsx      # Админ хяналтын самбар
│       ├── products/
│       │   ├── page.tsx            # Барааны жагсаалт
│       │   └── new/page.tsx        # Бараа нэмэх
│       └── orders/page.tsx         # Захиалгын удирдлага
├── components/
│   ├── layout/Header.tsx           # Навигаци хэсэг
│   ├── products/
│   │   ├── ProductCard.tsx         # Барааны карт
│   │   └── AddToCartButton.tsx     # Сагсанд нэмэх
│   └── admin/
│       ├── AdminProductActions.tsx # Засах/устгах
│       └── OrderStatusUpdater.tsx  # Захиалгын төлөв
├── lib/
│   ├── supabase/
│   │   ├── client.ts               # Browser client
│   │   ├── server.ts               # Server client
│   │   └── middleware.ts           # Auth middleware
│   └── utils.ts                    # Туслах функцууд
├── types/index.ts                  # TypeScript types
└── middleware.ts                   # Next.js middleware
```

## Онцлог функцууд

- ✅ Нэвтрэх / Бүртгүүлэх (Supabase Auth)
- ✅ Бараа харах, хайх, ангилалаар шүүх
- ✅ Дэлгэрэнгүй мэдээлэл
- ✅ Сагс (localStorage)
- ✅ Захиалга хийх
- ✅ Захиалгын түүх (профайл)
- ✅ Админ хяналтын самбар
- ✅ Барааны CRUD
- ✅ Захиалгын төлөв өөрчлөх
- ✅ RLS хамгаалалт
